#ifndef FILA_H
#define FILA_H


class Fila
{
    public:
        Fila();
        virtual ~Fila();

    protected:

    private:
};

#endif // FILA_H
